'use strict';

/**
 * Build script — sab kuch ek self-contained index.html me daal deta hai
 * (CSS + JS + Devanagari font inline). Isse site file-preview me bhi
 * poore design ke saath dikhti hai, aur server bhi wahi file serve karta hai.
 *
 * Run:  node build.js
 */

const fs = require('fs');
const path = require('path');

const PUB = path.join(__dirname, 'public');
const read = (f) => fs.readFileSync(path.join(PUB, f), 'utf8');
const b64 = (f) => fs.readFileSync(path.join(PUB, f)).toString('base64');

let css = read('styles.css');

// fonts -> data URIs (preview iframes me network nahi hota)
const devFont = b64('fonts/noto-sans-devanagari.woff2');
const latFont = b64('fonts/noto-sans-devanagari-latin.woff2');
css = css
  .replace("url('/fonts/noto-sans-devanagari.woff2')", `url(data:font/woff2;base64,${devFont})`)
  .replace("url('/fonts/noto-sans-devanagari-latin.woff2')", `url(data:font/woff2;base64,${latFont})`);

const extraCss = `
/* preview / offline banner */
.offline-bar {
  position: relative; z-index: 60;
  background: linear-gradient(90deg, #fff3dc, #ffe9c2);
  border-bottom: 1px solid #f0d59b;
  color: #7a4b00; font-size: 12.8px; line-height: 1.45;
  padding: 9px 16px; text-align: center; font-weight: 600;
}
.offline-bar b { color: #5c3800; }
body.has-offline-bar .nav { top: 0; }
`;

const js = [
  '/* ---- symbols ---- */\n' + read('symbols.js'),
  '/* ---- offline/preview mode ---- */\n' + read('offline.js'),
  '/* ---- app ---- */\n' + read('app.js'),
].join('\n\n');

let html = read('template.html');
// NOTE: replacement ko function me dena zaroori hai — warna JS ke `$$`/`$'`
// jaise patterns replace-string me special maane jaate hain aur code corrupt ho jata hai.
html = html.replace('<!-- INLINE_CSS_MARKER -->', () => `<style>\n${css}\n${extraCss}</style>`);
html = html.replace('<!-- INLINE_JS_MARKER -->', () => `<script>\n${js}\n</script>`);

fs.writeFileSync(path.join(PUB, 'index.html'), html, 'utf8');
const kb = (Buffer.byteLength(html) / 1024).toFixed(1);
console.log(`✅ built public/index.html (${kb} KB, self-contained)`);
